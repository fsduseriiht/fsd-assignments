/**
 * 
 */
package com.cts.fsd.tasktracker.test;

import java.io.IOException;
import java.text.ParseException;

/**
 * @author Amitabha Das [420652]
 * TestClass is used to perform POC work
 */
public class TestClass {

	/**
	 * main() method is perform rough work within the application for any POC or Test purpose
	 * @param args
	 * @throws ParseException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws ParseException, IOException {
//		String content = "Hello World !!";
//		Files.write(Paths.get("./src/main/java/com/cts/fsd/tasktracker/test/Test.txt"), content.getBytes());
	}

}
